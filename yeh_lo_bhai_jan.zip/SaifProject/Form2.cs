﻿using System;
using System.Windows.Forms;

namespace PacketFilteringApp
{
    public partial class RulesForm : Form
    {
        public RulesForm()
        {
            InitializeComponent();
        }

        private void btnSaveRule_Click(object sender, EventArgs e)
        {
            // Ensure all fields are filled
            if (string.IsNullOrWhiteSpace(txtSourceIP.Text) || string.IsNullOrWhiteSpace(txtDestinationIP.Text) ||
                string.IsNullOrWhiteSpace(txtSourcePort.Text) || string.IsNullOrWhiteSpace(txtDestinationPort.Text) ||
                string.IsNullOrWhiteSpace(txtProtocol.Text) || string.IsNullOrWhiteSpace(txtData.Text) ||
                string.IsNullOrWhiteSpace(txtDecision.Text))
            {
                MessageBox.Show("Please fill all fields before saving the rule.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Save rule to file
            string rule = $"{txtSourceIP.Text};{txtDestinationIP.Text};{txtSourcePort.Text};{txtDestinationPort.Text};{txtProtocol.Text};{txtData.Text};{txtDecision.Text}";
            System.IO.File.AppendAllText("rules.txt", rule + Environment.NewLine);
            MessageBox.Show("Rule saved successfully!");
            ClearForm();
        }

        private void ClearForm()
        {
            txtSourceIP.Clear();
            txtDestinationIP.Clear();
            txtSourcePort.Clear();
            txtDestinationPort.Clear();
            txtProtocol.Clear();
            txtData.Clear();
            txtDecision.Clear();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
