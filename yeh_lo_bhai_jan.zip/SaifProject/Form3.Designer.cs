﻿namespace PacketFilteringApp
{
    partial class PacketsForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox txtSourceIP;
        private System.Windows.Forms.TextBox txtDestinationIP;
        private System.Windows.Forms.TextBox txtSourcePort;
        private System.Windows.Forms.TextBox txtDestinationPort;
        private System.Windows.Forms.TextBox txtProtocol;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.Button btnCheckPacket;
        private System.Windows.Forms.Label lblSourceIP;
        private System.Windows.Forms.Label lblDestinationIP;
        private System.Windows.Forms.Label lblSourcePort;
        private System.Windows.Forms.Label lblDestinationPort;
        private System.Windows.Forms.Label lblProtocol;
        private System.Windows.Forms.Label lblData;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.txtSourceIP = new System.Windows.Forms.TextBox();
            this.txtDestinationIP = new System.Windows.Forms.TextBox();
            this.txtSourcePort = new System.Windows.Forms.TextBox();
            this.txtDestinationPort = new System.Windows.Forms.TextBox();
            this.txtProtocol = new System.Windows.Forms.TextBox();
            this.txtData = new System.Windows.Forms.TextBox();
            this.btnCheckPacket = new System.Windows.Forms.Button();
            this.lblSourceIP = new System.Windows.Forms.Label();
            this.lblDestinationIP = new System.Windows.Forms.Label();
            this.lblSourcePort = new System.Windows.Forms.Label();
            this.lblDestinationPort = new System.Windows.Forms.Label();
            this.lblProtocol = new System.Windows.Forms.Label();
            this.lblData = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtSourceIP
            // 
            this.txtSourceIP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSourceIP.Location = new System.Drawing.Point(165, 136);
            this.txtSourceIP.Name = "txtSourceIP";
            this.txtSourceIP.Size = new System.Drawing.Size(200, 26);
            this.txtSourceIP.TabIndex = 1;
            // 
            // txtDestinationIP
            // 
            this.txtDestinationIP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDestinationIP.Location = new System.Drawing.Point(165, 200);
            this.txtDestinationIP.Name = "txtDestinationIP";
            this.txtDestinationIP.Size = new System.Drawing.Size(200, 26);
            this.txtDestinationIP.TabIndex = 3;
            // 
            // txtSourcePort
            // 
            this.txtSourcePort.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSourcePort.Location = new System.Drawing.Point(165, 263);
            this.txtSourcePort.Name = "txtSourcePort";
            this.txtSourcePort.Size = new System.Drawing.Size(200, 26);
            this.txtSourcePort.TabIndex = 5;
            // 
            // txtDestinationPort
            // 
            this.txtDestinationPort.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDestinationPort.Location = new System.Drawing.Point(165, 334);
            this.txtDestinationPort.Name = "txtDestinationPort";
            this.txtDestinationPort.Size = new System.Drawing.Size(200, 26);
            this.txtDestinationPort.TabIndex = 7;
            // 
            // txtProtocol
            // 
            this.txtProtocol.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtProtocol.Location = new System.Drawing.Point(165, 398);
            this.txtProtocol.Name = "txtProtocol";
            this.txtProtocol.Size = new System.Drawing.Size(200, 26);
            this.txtProtocol.TabIndex = 9;
            // 
            // txtData
            // 
            this.txtData.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtData.Location = new System.Drawing.Point(165, 463);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(200, 26);
            this.txtData.TabIndex = 11;
            // 
            // btnCheckPacket
            // 
            this.btnCheckPacket.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(144)))), ((int)(((byte)(217)))));
            this.btnCheckPacket.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(144)))), ((int)(((byte)(217)))));
            this.btnCheckPacket.FlatAppearance.BorderSize = 2;
            this.btnCheckPacket.Font = new System.Drawing.Font("Impact", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheckPacket.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(32)))), ((int)(((byte)(44)))));
            this.btnCheckPacket.Location = new System.Drawing.Point(135, 525);
            this.btnCheckPacket.Name = "btnCheckPacket";
            this.btnCheckPacket.Size = new System.Drawing.Size(265, 59);
            this.btnCheckPacket.TabIndex = 12;
            this.btnCheckPacket.Text = "Check";
            this.btnCheckPacket.UseVisualStyleBackColor = false;
            this.btnCheckPacket.Click += new System.EventHandler(this.btnCheckPacket_Click);
            // 
            // lblSourceIP
            // 
            this.lblSourceIP.AutoSize = true;
            this.lblSourceIP.Font = new System.Drawing.Font("HP Simplified Jpan", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSourceIP.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(32)))), ((int)(((byte)(44)))));
            this.lblSourceIP.Location = new System.Drawing.Point(225, 113);
            this.lblSourceIP.Name = "lblSourceIP";
            this.lblSourceIP.Size = new System.Drawing.Size(87, 23);
            this.lblSourceIP.TabIndex = 0;
            this.lblSourceIP.Text = "Source IP";
            // 
            // lblDestinationIP
            // 
            this.lblDestinationIP.AutoSize = true;
            this.lblDestinationIP.Font = new System.Drawing.Font("HP Simplified Jpan", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDestinationIP.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(32)))), ((int)(((byte)(44)))));
            this.lblDestinationIP.Location = new System.Drawing.Point(210, 177);
            this.lblDestinationIP.Name = "lblDestinationIP";
            this.lblDestinationIP.Size = new System.Drawing.Size(126, 23);
            this.lblDestinationIP.TabIndex = 2;
            this.lblDestinationIP.Text = "Destination IP";
            // 
            // lblSourcePort
            // 
            this.lblSourcePort.AutoSize = true;
            this.lblSourcePort.Font = new System.Drawing.Font("HP Simplified Jpan", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSourcePort.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(32)))), ((int)(((byte)(44)))));
            this.lblSourcePort.Location = new System.Drawing.Point(211, 240);
            this.lblSourcePort.Name = "lblSourcePort";
            this.lblSourcePort.Size = new System.Drawing.Size(106, 23);
            this.lblSourcePort.TabIndex = 4;
            this.lblSourcePort.Text = "Source Port";
            // 
            // lblDestinationPort
            // 
            this.lblDestinationPort.AutoSize = true;
            this.lblDestinationPort.Font = new System.Drawing.Font("HP Simplified Jpan", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDestinationPort.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(32)))), ((int)(((byte)(44)))));
            this.lblDestinationPort.Location = new System.Drawing.Point(191, 308);
            this.lblDestinationPort.Name = "lblDestinationPort";
            this.lblDestinationPort.Size = new System.Drawing.Size(145, 23);
            this.lblDestinationPort.TabIndex = 6;
            this.lblDestinationPort.Text = "Destination Port";
            // 
            // lblProtocol
            // 
            this.lblProtocol.AutoSize = true;
            this.lblProtocol.Font = new System.Drawing.Font("HP Simplified Jpan", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProtocol.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(32)))), ((int)(((byte)(44)))));
            this.lblProtocol.Location = new System.Drawing.Point(225, 375);
            this.lblProtocol.Name = "lblProtocol";
            this.lblProtocol.Size = new System.Drawing.Size(80, 23);
            this.lblProtocol.TabIndex = 8;
            this.lblProtocol.Text = "Protocol";
            // 
            // lblData
            // 
            this.lblData.AutoSize = true;
            this.lblData.Font = new System.Drawing.Font("HP Simplified Jpan", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblData.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(32)))), ((int)(((byte)(44)))));
            this.lblData.Location = new System.Drawing.Point(236, 437);
            this.lblData.Name = "lblData";
            this.lblData.Size = new System.Drawing.Size(49, 23);
            this.lblData.TabIndex = 10;
            this.lblData.Text = "Data";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(68)))), ((int)(((byte)(156)))));
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(-8, -6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(605, 18);
            this.panel1.TabIndex = 16;
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(0, 23);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(970, 41);
            this.panel2.TabIndex = 5;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(144)))), ((int)(((byte)(217)))));
            this.panel3.Controls.Add(this.button2);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Location = new System.Drawing.Point(-2, 12);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(599, 29);
            this.panel3.TabIndex = 17;
            // 
            // panel4
            // 
            this.panel4.Location = new System.Drawing.Point(0, 23);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(970, 41);
            this.panel4.TabIndex = 5;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.BackgroundImage = global::SaifProject.Properties.Resources.icons8_multiply_48;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.button2.Location = new System.Drawing.Point(520, -1);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(28, 27);
            this.button2.TabIndex = 18;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Impact", 16F);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(32)))), ((int)(((byte)(44)))));
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(89, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(392, 39);
            this.label2.TabIndex = 18;
            this.label2.Text = "You can Check Packets here!";
            // 
            // PacketsForm
            // 
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(558, 644);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnCheckPacket);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.lblData);
            this.Controls.Add(this.txtProtocol);
            this.Controls.Add(this.lblProtocol);
            this.Controls.Add(this.txtDestinationPort);
            this.Controls.Add(this.lblDestinationPort);
            this.Controls.Add(this.txtSourcePort);
            this.Controls.Add(this.lblSourcePort);
            this.Controls.Add(this.txtDestinationIP);
            this.Controls.Add(this.lblDestinationIP);
            this.Controls.Add(this.txtSourceIP);
            this.Controls.Add(this.lblSourceIP);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "PacketsForm";
            this.Text = "PacketsForm";
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label2;
    }
}
