﻿using System;
using System.Windows.Forms;

namespace PacketFilteringApp
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void btnRules_Click(object sender, EventArgs e)
        {
            RulesForm rulesForm = new RulesForm();
            rulesForm.Show();
        }

        private void btnPackets_Click(object sender, EventArgs e)
        {
            PacketsForm packetsForm = new PacketsForm();
            packetsForm.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
