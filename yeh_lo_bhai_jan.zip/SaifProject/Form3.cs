﻿using System;
using System.Windows.Forms;

namespace PacketFilteringApp
{
    public partial class PacketsForm : Form
    {
        public PacketsForm()
        {
            InitializeComponent();
        }

        private void btnCheckPacket_Click(object sender, EventArgs e)
        {
            string[] rules = System.IO.File.ReadAllLines("rules.txt");
            for (int i = 0; i < rules.Length; i++)
            {
                string[] parts = rules[i].Split(';');
                string matchedAttribute = string.Empty;

                if (parts.Length == 7)
                {
                    if (parts[0] == txtSourceIP.Text)
                    {
                        matchedAttribute = "Source IP";
                    }
                    else if (parts[1] == txtDestinationIP.Text)
                    {
                        matchedAttribute = "Destination IP";
                    }
                    else if (parts[2] == txtSourcePort.Text)
                    {
                        matchedAttribute = "Source Port";
                    }
                    else if (parts[3] == txtDestinationPort.Text)
                    {
                        matchedAttribute = "Destination Port";
                    }
                    else if (parts[4] == txtProtocol.Text)
                    {
                        matchedAttribute = "Protocol";
                    }
                    else if (parts[5].Contains(txtData.Text))
                    {
                        matchedAttribute = "Rule Data";
                    }
                    else if (txtData.Text.Contains(parts[5]))
                    {
                        matchedAttribute = "Packet Data";
                    }

                    if (!string.IsNullOrEmpty(matchedAttribute))
                    {
                        string currentTime = DateTime.Now.ToString("HH:mm:ss");
                        MessageBox.Show($"Matching Rule Number: {i + 1}\nDecision: {parts[6]}\nMatched Attribute: {matchedAttribute}\nTime: {currentTime}");
                        return;
                    }
                }
            }
            MessageBox.Show("No matching rule found.");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
